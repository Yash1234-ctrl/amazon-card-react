const products = [
  {
    id: 1,
    name: "Redmi Note 13",
    price: 13999,
    image: "https://m.media-amazon.com/images/I/61aFj0sbkYL._AC_UY327_FMwebp_QL65_.jpg",
    rating: 4.3
  },
  {
    id: 2,
    name: "Samsung Galaxy S23",
    price: 49999,
    image: "https://m.media-amazon.com/images/I/71oGzXIlFVL._AC_UY327_FMwebp_QL65_.jpg",
    rating: 4.6
  },
  {
    id: 3,
    name: "Apple iPhone 15",
    price: 71999,
    image: "https://m.media-amazon.com/images/I/81fxjeu8fdL._AC_UY327_FMwebp_QL65_.jpg",
    rating: 4.8
  }
];

export default products;
