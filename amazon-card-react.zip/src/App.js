import React from 'react';
import ProductCard from './components/ProductCard';
import products from './data/products';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Amazon Products</h1>
      <div className="product-grid">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}

export default App;
